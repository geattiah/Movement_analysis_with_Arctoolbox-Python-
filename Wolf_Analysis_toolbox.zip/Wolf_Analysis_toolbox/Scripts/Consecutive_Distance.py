#coding= utf-8
"""-----------------------------------------------------------------------------
  Script Name: Generating Distances between consecutive points
  Description: Showing movement distnace between consecurive points in data
  Created By:  Stiftung_Naturschutz SH.
  Date:        28 May, 2019.
-----------------------------------------------------------------------------"""
import arcpy
import os
import sys
from arcpy import env

arcpy.env.overwriteOutput = True

#WOLF SCRIPT

#DATA INPUTS AND OUTPUTS
Input_data = arcpy.GetParameterAsText(0)

Output_data
Output_data = arcpy.GetParameterAsText(1)


#Sort Fields

arcpy.Sort_management(Input_data,Output_data,"DATUM ASCENDING","UR")


#Add field
#arcpy.AddField_management(Output_data,"Distance","DOUBLE")


#Calculate distance

#arcpy.CalculateField_management(Output_data,"Distance", "dist( !Shape! )","PYTHON","count = 0\ndef dist(shape):\n    global prev\n    global count\n    point = arcpy.PointGeometry(shape.getPart(0))\n    if count > 0:\n        distance = point.distanceTo(prev)\n    else:\n        distance = 0\n    prev = point\n    count = count+1\n    return distance")



